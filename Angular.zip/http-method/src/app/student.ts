export interface Student {
  id: number;
  name: string;
  course: string;
}