import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface Message {
  sender: string;
  text: string;
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './app.html',
  styleUrls: ['./app.css']   
})
export class App {

  selectedUser: string = 'A';
  newMessage: string = '';
  messages: Message[] = [];

  sendMessage() {
    if (this.newMessage.trim()) {
      this.messages.push({
        sender: this.selectedUser,
        text: this.newMessage
      });
      this.newMessage = '';
    }
  }
}