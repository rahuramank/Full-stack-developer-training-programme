import { Component, signal } from '@angular/core';
import { DataBind } from './data-bind/data-bind';
import { Bind } from './bind/bind';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-root',
  imports: [DataBind,Bind],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('databinding');
}
