import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-data-bind',
  standalone:true,
  imports: [],
  templateUrl: './data-bind.html',
  styleUrl: './data-bind.css',
})
export class DataBind {

}
