import { Component, signal } from '@angular/core';
import { Hotel } from './hotel/hotel';
import { Room1 } from './room-1';

@Component({
  selector: 'app-root',
  standalone:true,
  imports: [Hotel],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('acservice');
}
