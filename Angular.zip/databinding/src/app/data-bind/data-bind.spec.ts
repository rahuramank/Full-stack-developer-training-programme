import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DataBind } from './data-bind';

describe('DataBind', () => {
  let component: DataBind;
  let fixture: ComponentFixture<DataBind>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DataBind]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DataBind);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
