import { Injectable } from '@angular/core';
import { Student } from '../student';
@Injectable({
  providedIn: 'root',
})
export class StudentService {

    // This array acts like a DATABASE
    private students: Student[] = [
    { id: 1, name: 'Raghu', course: 'Java' },
    { id: 2, name: 'Balaji', course: 'Angular' },
    { id: 3, name: 'Hari', course: 'Java' }
  ];
  constructor() {}
  // 🔹 GET – Read data
  getStudents(): Student[] {
    return this.students;
  }
  // 🔹 POST – Add data
  addStudent(student: Student): void {
    this.students.push(student);
  }
  // 🔹 PUT – Update data
  updateStudent(id: number, updatedStudent: Student): void {
    const index = this.students.findIndex(s => s.id === id);
    if (index !== -1) {
      this.students[index] = updatedStudent;
    }
  }
  // 🔹 DELETE – Remove data
  deleteStudent(id: number): void {
    this.students = this.students.filter(s => s.id !== id);
  }
}
