import { Component } from '@angular/core';

@Component({
  selector: 'app-test',
  standalone:true,
  imports: [],
  templateUrl: './test.html',
  styleUrl: './test.css',
})
export class Test {
name:string="Raghu";
course:string="Full Stack Developer";
fees:number=10000
}
