import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Inbuilt } from './inbuilt';

describe('Inbuilt', () => {
  let component: Inbuilt;
  let fixture: ComponentFixture<Inbuilt>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Inbuilt]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Inbuilt);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
