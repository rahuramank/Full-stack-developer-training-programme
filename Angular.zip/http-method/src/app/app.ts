import { Student } from './student';
import { Component, signal } from '@angular/core';
import { StudentService } from './services/student-service';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('http-methods');

  
  students: Student[] = [];

  constructor(private studentService: StudentService) {}

  ngOnInit() {
    this.getAllStudents();
  }

  // GET
  getAllStudents() {
    this.students = this.studentService.getStudents();
  }

  // POST
  addStudent() {
    const student: Student = {
      id: this.students.length + 1,
      name: 'Damo',
      course: 'React'
    };
    this.studentService.addStudent(student);
    this.getAllStudents();
  }

  // PUT
  updateStudent() {
    const student: Student = {
      id: 2,
      name: 'Anita',
      course: 'Spring Boot'
    };
    this.studentService.updateStudent(2, student);
    this.getAllStudents();
  }

  // DELETE
  deleteStudent() {
  const input = prompt('Enter Student ID to delete:');

  if (input === null) return; // user cancelled

  const id = Number(input);

  if (isNaN(id)) {
    alert('Please enter a valid number');
    return;
  }

  this.studentService.deleteStudent(id);
  this.getAllStudents();
}

}
