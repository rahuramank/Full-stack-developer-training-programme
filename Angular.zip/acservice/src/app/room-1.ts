import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class Room1 {
    turnOn() 
  {
    return 'AC is ON ++++';
  }
    turnOff() 
  {
    return 'AC is OFF ----';
  }
}
