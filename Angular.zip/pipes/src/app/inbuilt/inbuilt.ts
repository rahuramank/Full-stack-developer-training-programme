
import { CommonModule } from '@angular/common';
import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';

@Component({
  selector: 'app-inbuilt',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './inbuilt.html',
  styleUrls: ['./inbuilt.css'], // ✅ FIXED (plural)
})
export class Inbuilt implements OnInit, OnDestroy {

  // 1️⃣ String value
  str: string = 'Hello Everyone';

  // 2️⃣ Number value (used for currency pipe)
  amount: number = 5000;

  // 3️⃣ Date value (used for date pipe)
    today: Date = new Date();
    
  // 4️⃣ Object value (used for json pipe)
  emp = {
    id: 101,
    name: 'Anand',
    role: 'Angular Developer',
    salary: 60000
  };

  private intervalId!: any;

  constructor(private cd: ChangeDetectorRef) {}

  // 🔁 Start live clock
  ngOnInit() {
    this.intervalId = setInterval(() => {
      this.today = new Date();
      this.cd.detectChanges();
    }, 1000);
  }

  // 🛑 Cleanup
  ngOnDestroy() {
    clearInterval(this.intervalId);
  }
}