package com.example.demo;

public class NestedTryCatch {
	public static void main(String[] args) {
		try {
			int a[] = { 10, 20, 30, 40 };
			System.out.println(a[0]);
			System.out.println(a[1]);
			System.out.println(a[2]);
			System.out.println(a[3]);
			/* System.out.println(a[4]); */
			try {
				System.out.println(a[4]);
			} catch (Exception d) {
				System.out.println("This is the error" + d);
			}
		} catch (ArithmeticException b1) {
			System.out.println("The error is " + b1);
			try {
				System.out.println(10 / 0);
			} catch (Exception e) {
				System.out.println("This is the Error" + e);
			}
		}
		System.out.println("Contiuing the program ........");
	}
}
