import { TestBed } from '@angular/core/testing';

import { Room1 } from './room-1';

describe('Room1', () => {
  let service: Room1;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Room1);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
