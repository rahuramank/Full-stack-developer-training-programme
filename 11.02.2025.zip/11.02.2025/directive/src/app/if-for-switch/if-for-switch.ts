import { Component } from '@angular/core';

@Component({
  selector: 'app-if-for-switch',
  imports: [],
  templateUrl: './if-for-switch.html',
  styleUrl: './if-for-switch.css',
})
export class IfForSwitch {

}
