package com.example.Car_application;

/*Dependency injection is implemented using setter and constructor injection*/

class PaymentService {
	public void pay() {
		System.out.println("Payment done using Credit Card");
	}
}

class Restaurant {
	private PaymentService paymentService;

	public void setPaymentService(PaymentService paymentService) {
		this.paymentService = paymentService;
	}

	public void orderFood() {
		System.out.println("Food ordered");
		paymentService.pay();
	}
}

public class Main {
	public static void main(String[] args) {
		Restaurant restaurant = new Restaurant();

		PaymentService payment = new PaymentService();

		restaurant.setPaymentService(payment);

		restaurant.orderFood();
	}
}