function validateform()
{
    var username= document.getElementById("username").value;
    var password= document.getElementById("password").value;
    if(username="")
    {
        alert("username cannot be empty");
        return false;
    }
    if(password=="")
    {
        alert("password cannot be empty");
        return false;
    }
    else("Welcome to home")
}