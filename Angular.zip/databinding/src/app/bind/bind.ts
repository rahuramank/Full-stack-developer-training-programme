import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-bind',
  standalone:true,
  imports: [FormsModule],
  templateUrl: './bind.html',
  styleUrl: './bind.css',
})
export class Bind 
{
  // string interpolation //
    name ="Raghuraman";

    // property binding //
    isDisabled =false;

    // Event binding //
    enableButton()
    {
      this.isDisabled=true;
    }
    // two way binding //
    username ="";
    showAlert()
    {
      alert('Hello ' + this.username);
    }
}
