import { Component } from '@angular/core';
import { Room1 } from '../room-1';

@Component({
  selector: 'app-hotel',
  standalone:true,
  imports: [],
  templateUrl: './hotel.html',
  styleUrls: ['./hotel.css'],
})
export class Hotel {
message = '';
constructor(private acService: Room1) {}
  // 👆 AC is injected here (DI) //
onAc() 
{
    this.message = this.acService.turnOn();
  }
offAc() 
{
    this.message = this.acService.turnOff();
  }
}
