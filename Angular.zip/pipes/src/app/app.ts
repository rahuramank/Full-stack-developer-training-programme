import { Component, signal } from '@angular/core';
import { Inbuilt } from "./inbuilt/inbuilt";

@Component({
  selector: 'app-root',
  standalone:true,
  imports: [Inbuilt],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('pipes');
}
