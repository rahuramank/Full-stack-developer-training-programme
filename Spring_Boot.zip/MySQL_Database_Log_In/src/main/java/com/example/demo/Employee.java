package com.example.demo;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Employee {

    @Id
    private int id;

    private String username;
    private String password;

    public Employee() {}

    // ✅ ADD THIS
    public String getUsername() {
        return username;
    }

    // ✅ ADD THIS
    public void setUsername(String username) {
        this.username = username;
    }

    // Existing
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}