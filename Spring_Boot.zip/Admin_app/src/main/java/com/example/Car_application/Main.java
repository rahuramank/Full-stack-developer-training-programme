package com.example.Car_application;

/*Admin class uses common logic from User class in java*/

class User {
    void login() {
        System.out.println("Login from User");
    }
}

class Admin extends User {
    void manageUsers() {
        System.out.println("Admin managing users");
    }
}

public class Main {
    public static void main(String[] args) {
        Admin admin = new Admin();

        admin.login();        
        admin.manageUsers();
    }
}