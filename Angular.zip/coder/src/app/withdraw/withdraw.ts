import { Component } from '@angular/core';

@Component({
  selector: 'app-withdraw',
  imports: [],
  templateUrl: './withdraw.html',
  styleUrl: './withdraw.css',
})
export class Withdraw {

}
