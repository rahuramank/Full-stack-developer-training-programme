package com.example.Car_application;

import org.springframework.stereotype.Service;
import com.example.Car_application.User;

@Service
public class UserService {

	public String login(User user) {

		if (user.getUsername().equals("admin") && user.getPassword().equals("1234")) {

			return "Login Successful";
		} else {
			return "Invalid Username or Password";
		}
	}
}